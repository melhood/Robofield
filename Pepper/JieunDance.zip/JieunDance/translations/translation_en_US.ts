<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior.xar:/Disco</name>
        <message>
            <location filename="behavior.xar" line="0"/>
            <source>Okay! I will dance to Stayin Alive.</source>
            <comment>Text</comment>
            <translation type="unfinished">Okay! I will dance to Stayin Alive.</translation>
        </message>
    </context>
    <context>
        <name>behavior.xar:/Random</name>
        <message>
            <source>I will show you my moves!</source>
            <comment>Text</comment>
            <translation type="obsolete">I will show you my moves!</translation>
        </message>
        <message>
            <location filename="behavior.xar" line="0"/>
            <source>Okay! I will show you my moves!</source>
            <comment>Text</comment>
            <translation type="unfinished">Okay! I will show you my moves!</translation>
        </message>
    </context>
    <context>
        <name>behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior.xar:/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior.xar" line="0"/>
            <source>What did you say? Please repeat again.</source>
            <comment>Text</comment>
            <translation type="unfinished">What did you say? Please repeat again.</translation>
        </message>
    </context>
</TS>
